# Primes.jl

[![Build Status](https://github.com/JuliaMath/Primes.jl/workflows/CI/badge.svg)](https://github.com/JuliaMath/Primes.jl/actions?query=workflow%3A%22CI%22+branch%3Amaster)
[![codecov](https://codecov.io/gh/JuliaMath/Primes.jl/graph/badge.svg?token=DI1wpcH9tB)](https://codecov.io/gh/JuliaMath/Primes.jl)

Documentation:

[![docs stable badge](https://img.shields.io/badge/docs-stable-blue.svg)](https://JuliaMath.github.io/Primes.jl/stable)
[![docs latest badge](https://img.shields.io/badge/docs-latest-blue.svg)](https://JuliaMath.github.io/Primes.jl/latest)

Julia functions for computing prime numbers.
