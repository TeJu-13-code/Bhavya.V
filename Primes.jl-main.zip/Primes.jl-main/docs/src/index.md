# Primes.jl

This package provides functions for computing prime numbers in Julia.

## Installation

This release is available for Julia versions 1.6 and up.

To install it, run

```julia
using Pkg ; Pkg.add("Primes")
```

from the Julia REPL.
